package Classes;

public class ColetaLogin extends ColetaCadastro {
    private String EmailLogin, senhaLogin;

    public String getEmailLogin() {
        return EmailLogin;
    }

    public void setEmailLogin(String EmailLogin) {
        this.EmailLogin = EmailLogin;
    }

    public String getSenhaLogin() {
        return senhaLogin;
    }

    public void setSenhaLogin(String senhaLogin) {
        this.senhaLogin = senhaLogin;
    }
}
